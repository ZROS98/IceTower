﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public CharacterController2D controller;
    public Animator animator;
    public FloatingJoystick floatingJoystick;
    public float runSpeed = 40f;
    private float horizontalMove = 0f;
    private float fallingSpeed = 0f;
    private bool jump = false;
    private Rigidbody2D rigidbody2D;

    private void Start()
    {
        rigidbody2D = GetComponent<Rigidbody2D>();
    }

    private void Update()
    {

        fallingSpeed = rigidbody2D.velocity.y;
        animator.SetFloat("FallingSpeed",fallingSpeed);

        
        //horizontalMove = (Input.GetAxisRaw("Horizontal") * runSpeed);

        // horizontalMove = (floatingJoystick.Horizontal * runSpeed);

        if (floatingJoystick.Horizontal >= 0.2f)
        {
            horizontalMove = runSpeed;
        }else if (floatingJoystick.Horizontal <= -0.2f)
        {
            horizontalMove = -runSpeed;
        }else
        {
            horizontalMove = 0f;
        }

        animator.SetFloat("Speed", Mathf.Abs(horizontalMove));
        
        float verticalMove = floatingJoystick.Vertical;
        if (verticalMove >= 0.5f&& controller.m_Grounded)
        {
            jump = true;
           // animator.SetBool("IsJumping", true);
        }
    }
    
    

    public void onLanding()
    {
        animator.SetBool("IsJumping", false);
    }

    private void FixedUpdate()
    {
        controller.Move(horizontalMove * Time.fixedDeltaTime, jump);
        jump = false;
       
    }
}