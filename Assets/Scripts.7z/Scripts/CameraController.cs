﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour
{
    public GameObject objectToFollow;
    public float followSpeed = 10;
    private float cameraMoveSpeed = 0.05f;
    public bool startCameraMovement = false;
    private bool jumpIsDone = false;

    private void FixedUpdate()
    {
        if (!jumpIsDone)
        {
            if (Input.GetButton("Jump"))
            {
                startCameraMovement = true;
                jumpIsDone = true;
                GameObject.FindGameObjectWithTag("StartPlatform").transform.SetParent(null,true);
            }
        }


        if (startCameraMovement)
        { 
            gameObject.transform.position = new Vector2(transform.position.x, transform.position.y + cameraMoveSpeed);

            if (objectToFollow.transform.position.y > transform.position.y)
            {
                Vector3 positionToFollow =
                    new Vector3(transform.position.x, objectToFollow.transform.position.y, transform.position.z);
                transform.position = Vector3.Lerp(transform.position, positionToFollow, followSpeed * Time.deltaTime);
            }
        }
    }

}