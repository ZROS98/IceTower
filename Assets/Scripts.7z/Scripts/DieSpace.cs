﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DieSpace : MonoBehaviour
{
    private GameObject santa;
    private Collider2D santaCollider;
    public AudioSource death;
    private GameObject afterDeathMenu;
    private GameObject scoreMenu;
    private void Start()
    {
        santa = GameObject.FindGameObjectWithTag("Player");
        santaCollider = santa.GetComponent<Collider2D>();
        afterDeathMenu = GameObject.FindGameObjectWithTag("AfterDeathMenu");
        scoreMenu = GameObject.FindGameObjectWithTag("ScoreMenu");
        afterDeathMenu.SetActive(false);
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other == santaCollider)
        { 
            death.Play();
            Debug.Log("Death");
            StartCoroutine(TimeDelay(2.5f));
            
        }
    }
    public IEnumerator TimeDelay(float seconds)
    {
        yield return new WaitForSeconds(seconds);
        scoreMenu.SetActive(false);
        afterDeathMenu.SetActive(true);
        Time.timeScale = 0;
    }
   
}

    
