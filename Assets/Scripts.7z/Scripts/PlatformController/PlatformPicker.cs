﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityNightPool;

public class PlatformPicker : MonoBehaviour
{ 
    private void Update()
    {
        PlatformPick();
    }

    public void PlatformPick()
    {
        if (transform.position.y < GameObject.FindWithTag("MainCamera").transform.position.y-25) {
            GetComponent<PoolObject>().Return();
        }
    }
}
