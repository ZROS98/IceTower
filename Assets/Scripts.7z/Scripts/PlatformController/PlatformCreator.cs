﻿using UnityEngine;
using UnityNightPool;

namespace UnityNightPool.Example
{
    public class PlatformCreator : MonoBehaviour
    {
        private Vector3 oldPlatformPosition = new Vector3(0,-15,9);
        private Vector3 CurrentPlatformPosition;
        private float distansFromCenterToEdgeOldPlatform;
        private float leftRandomLimitX;
        private float rightRandomLimitX;
        private const float jumpLenght = 9;
        private const float jumpHeight = 4;
        private const float radiusCreativeZone = 9;

        private void Start()
        {
            while (oldPlatformPosition.y - GameObject.FindGameObjectWithTag("Player").transform.position.y < 40)
            {
                 CreatePlatform();
            }
        }
        void Update()
        {
           if (oldPlatformPosition.y-GameObject.FindGameObjectWithTag("Player").transform.position.y < 40)
            {
                CreatePlatform();
            }
        }

        private void CreatePlatform()
        {
            int idPlatform = Random.Range(1, 4);
            PoolObject platform = PoolManager.Get(idPlatform);
            float distansFromCenterToEdgeCurrentPlatform = platform.GetComponent<BoxCollider2D>().size.x * platform.transform.localScale.x / 2;
            float radiusCreativeZoneRelativeToCurrentPlatform = radiusCreativeZone + distansFromCenterToEdgeCurrentPlatform - 1;

            float YPossitionCurrentPlatformRelativeToZero = Random.Range(2, jumpHeight);
            float YPossitionCurrentPlatformRelativeToCharacter = YPossitionCurrentPlatformRelativeToZero + oldPlatformPosition.y;
            
            float CurrentJumpLenghtForThisY = MaxXforThisY(FindAforThisParabola(jumpLenght, 0, jumpHeight), YPossitionCurrentPlatformRelativeToZero, jumpHeight) 
                + distansFromCenterToEdgeCurrentPlatform + distansFromCenterToEdgeOldPlatform;

            leftRandomLimitX = oldPlatformPosition.x - CurrentJumpLenghtForThisY < -radiusCreativeZoneRelativeToCurrentPlatform ? 
                -radiusCreativeZoneRelativeToCurrentPlatform : oldPlatformPosition.x - CurrentJumpLenghtForThisY;
            
            rightRandomLimitX = oldPlatformPosition.x + CurrentJumpLenghtForThisY > radiusCreativeZoneRelativeToCurrentPlatform ? 
                radiusCreativeZoneRelativeToCurrentPlatform : oldPlatformPosition.x + CurrentJumpLenghtForThisY;

            CurrentPlatformPosition = new Vector3(
                RandomWithConditions(leftRandomLimitX, rightRandomLimitX,
                    oldPlatformPosition.x - CurrentJumpLenghtForThisY / 2,
                    oldPlatformPosition.x + CurrentJumpLenghtForThisY / 2),
                YPossitionCurrentPlatformRelativeToCharacter, oldPlatformPosition.z);
            platform.transform.position = CurrentPlatformPosition;
            oldPlatformPosition = CurrentPlatformPosition;
            distansFromCenterToEdgeOldPlatform = distansFromCenterToEdgeCurrentPlatform;
        }

        private float RandomWithConditions(float min, float max, float conditionOne, float conditionTwo)
        {
            float randomNumber = Random.Range(leftRandomLimitX, rightRandomLimitX);

            if(randomNumber > conditionOne && randomNumber < conditionTwo)
            {
                return RandomWithConditions(min, max, conditionOne, conditionTwo);
            }
            return randomNumber;
        }


        //find the maximum value of X for the platform located at the specified Y, on which the character can jump
        private float FindAforThisParabola(float x, float y, float c)
        {
            float axSquared = y - c;
            float a = axSquared / (float)System.Math.Pow(x, 2f);
            return a;
        }
        private float MaxXforThisY(float a, float y, float c)
        {
            float axSquared = y - c;    
            float xSquared = axSquared / a;
            float x = (float)System.Math.Sqrt(xSquared);
            return x;
        }
    }
}