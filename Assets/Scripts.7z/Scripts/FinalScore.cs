﻿using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class FinalScore : MonoBehaviour
{
    private GameObject currentScore;
    private TextMeshProUGUI scoreText;
    void Start()
    {
        currentScore = GameObject.Find("Score Text");
        scoreText = gameObject.GetComponent<TextMeshProUGUI>();
       
    }

    // Update is called once per frame
    void Update()
    {
        scoreText.text = currentScore.GetComponent<Text>().text;
    }
}
