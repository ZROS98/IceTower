﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityNightPool;

public class GameMenu : MonoBehaviour
{
    private bool isPaused = false;
    private Array arrayPlatforms;
    private PoolObject poolObject;
    
    public void PauseGame()
    {
        Debug.Log("paused");
        if (isPaused)
        {
            Time.timeScale = 1;
            isPaused = false;
        }
        else
        {
            Time.timeScale = 0;
            isPaused = true;
        }
    }

    public void BackToMainMenu()
    {
        arrayPlatforms = GameObject.FindGameObjectsWithTag("Platform");
        foreach (GameObject platform in arrayPlatforms)
        {
            poolObject = platform.GetComponent<PoolObject>();
            poolObject.Return();
        }
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex -1);
    }
}
