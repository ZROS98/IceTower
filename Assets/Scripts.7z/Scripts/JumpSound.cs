﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class JumpSound : MonoBehaviour
{
   public AudioSource jump;
   private GameObject santa;
   

   private void Start()
   {
      santa = GameObject.FindGameObjectWithTag("Player");
   }

   private void Update()
   {
      bool grounded = santa.GetComponent<CharacterController2D>().m_Grounded;
      if (Input.GetButtonDown("Jump")&& grounded)
      {
         jump.Play();
      }
   }
}
