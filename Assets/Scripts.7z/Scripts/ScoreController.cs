﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Experimental.PlayerLoop;
using UnityEngine.UI;

public class ScoreController : MonoBehaviour
{
    private int score = 0;
    private float currentHight = -11f;
    private float oldHight = -11f;
    private Text scoreText;

    private void Start()
    {
        scoreText = gameObject.GetComponent<Text>();
    }

    private void Update()
    {
        GameObject player = GameObject.FindWithTag("Player");

        currentHight = 11 +player.transform.position.y;

        if (currentHight > oldHight)
        {
            oldHight = currentHight;

            score = (int)oldHight;
            
            scoreText.text =""+score;
        }
    }
}
