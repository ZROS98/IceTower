﻿using System;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityNightPool;

public class Restart : MonoBehaviour
{
    private Array arrayPlatforms;
    private PoolObject poolObject;

    public void RestartGame()
    {
        arrayPlatforms = GameObject.FindGameObjectsWithTag("Platform");
        foreach (GameObject platform in arrayPlatforms)
        {
            poolObject = platform.GetComponent<PoolObject>();
            poolObject.Return();
        }
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        Time.timeScale = 1;
    }
}